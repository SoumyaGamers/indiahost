var _$_ea80 = ["\x44\x4F\x4D\x43\x6F\x6E\x74\x65\x6E\x74\x4C\x6F\x61\x64\x65\x64", "\x43\x75\x72\x54\x6F\x67\x67\x6C\x65", "\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64", "\x4D\x6F\x64\x61\x6C", "\x74\x6F\x55\x54\x43\x53\x74\x72\x69\x6E\x67", "\x6E\x6F\x77", "\x63\x6F\x6F\x6B\x69\x65", "\x3D", "\x3B\x20\x65\x78\x70\x69\x72\x65\x73\x3D", "\x3B\x20\x70\x61\x74\x68\x3D\x2F\x3B\x20\x53\x61\x6D\x65\x53\x69\x74\x65\x3D\x4C\x61\x78", "\x28\x3F\x3A\x5E\x7C\x3B\x20\x29", "\x5C\x24\x31", "\x72\x65\x70\x6C\x61\x63\x65", "\x3D\x28\x5B\x5E\x3B\x5D\x2A\x29", "\x6D\x61\x74\x63\x68", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x69\x70\x61\x70\x69\x2E\x63\x6F\x2F\x6A\x73\x6F\x6E\x2F", "\x6F\x6B", "\x46\x61\x69\x6C\x65\x64\x20\x74\x6F\x20\x66\x65\x74\x63\x68\x20\x49\x50\x20\x69\x6E\x66\x6F", "\x6A\x73\x6F\x6E", "\x45\x72\x72\x6F\x72\x20\x66\x65\x74\x63\x68\x69\x6E\x67\x20\x49\x50\x20\x69\x6E\x66\x6F\x3A", "\x65\x72\x72\x6F\x72", "\x32", "\x49\x4E\x52", "\x31", "\x73\x70\x61\x72\x6B\x5F\x63\x75\x72", "\x73\x74\x6F\x72\x65\x64\x43\x75\x72\x72\x65\x6E\x63\x79\x56\x61\x6C\x75\x65", "\x73\x65\x74\x49\x74\x65\x6D", "\x70\x72\x65\x76\x65\x6E\x74\x44\x65\x66\x61\x75\x6C\x74", "\x64\x61\x74\x61\x2D\x63\x75\x72\x72\x65\x6E\x63\x79", "\x67\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65", "\x68\x69\x64\x65", "\x67\x65\x74\x49\x74\x65\x6D", "\x2E\x62\x74\x6E\x2D\x6C\x69\x6E\x65\x5B\x64\x61\x74\x61\x2D\x63\x75\x72\x72\x65\x6E\x63\x79\x5D", "\x71\x75\x65\x72\x79\x53\x65\x6C\x65\x63\x74\x6F\x72", "\x24\x20\x55\x53\x44", "\u20B9\x20\x49\x4E\x52", "\x74\x65\x78\x74\x43\x6F\x6E\x74\x65\x6E\x74", "", "\x64\x61\x74\x61\x2D\x69\x6E\x72", "\x64\x61\x74\x61\x2D\x75\x73\x64", "\x2E\x74\x65\x78\x74\x2D\x77\x68\x69\x74\x65", "\x66\x6F\x72\x45\x61\x63\x68", "\x2E\x64\x69\x70\x65\x73\x68", "\x71\x75\x65\x72\x79\x53\x65\x6C\x65\x63\x74\x6F\x72\x41\x6C\x6C", "\x63\x75\x72\x72\x65\x6E\x63\x79", "\x55\x53\x44", "\x23\x43\x75\x72\x54\x6F\x67\x67\x6C\x65\x20\x2E\x6C\x69\x73\x74\x2D\x67\x72\x6F\x75\x70\x2D\x69\x74\x65\x6D", "\x63\x6C\x69\x63\x6B", "\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72", "\x74\x6F\x4C\x6F\x77\x65\x72\x43\x61\x73\x65", "\x64\x61\x74\x61\x2D\x66\x69\x6C\x74\x65\x72", "\x2E\x62\x75\x74\x74\x6F\x6E\x2D\x67\x72\x6F\x75\x70\x20\x2E\x73\x65\x6C\x65\x63\x74\x65\x64", "\u20B9", "\x24", "\x6D\x6F\x6E\x74\x68\x6C\x79", "\x79\x65\x61\x72\x6C\x79", "\x62\x69\x65\x6E\x6E\x69\x61\x6C\x6C\x79", "\x74\x72\x69\x65\x6E\x6E\x69\x61\x6C\x6C\x79", "\x69\x6E\x63\x6C\x75\x64\x65\x73", "\x2D\x69\x6E\x72", "\x2D\x75\x73\x64", "\x2E\x70\x72\x69\x63\x65\x2D\x61\x6D\x6F\x75\x6E\x74", "\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C", "\x3C\x73\x70\x61\x6E\x20\x63\x6C\x61\x73\x73\x3D\x22\x62\x69\x6C\x6C\x69\x6E\x67\x2D\x63\x79\x63\x6C\x65\x22\x3E\x20\x2F", "\x3C\x2F\x73\x70\x61\x6E\x3E", "\x4E\x6F\x74\x20\x41\x76\x61\x69\x6C\x61\x62\x6C\x65", "\x23\x64\x69\x70\x65\x73\x68\x37\x38\x36", "\x74\x6F\x55\x70\x70\x65\x72\x43\x61\x73\x65", "\x63\x68\x61\x72\x41\x74", "\x73\x6C\x69\x63\x65", "\x2E\x62\x69\x6C\x6C\x69\x6E\x67\x2D\x63\x79\x63\x6C\x65\x2D\x62\x75\x74\x74\x6F\x6E", "\x73\x65\x6C\x65\x63\x74\x65\x64", "\x72\x65\x6D\x6F\x76\x65", "\x63\x6C\x61\x73\x73\x4C\x69\x73\x74", "\x61\x64\x64", "\x37\x20\x44\x61\x79\x73\x20\x4D\x6F\x6E\x65\x79\x20\x42\x61\x63\x6B\x20\x47\x75\x61\x72\x61\x6E\x74\x65\x65", "\x33\x30\x20\x44\x61\x79\x73\x20\x4D\x6F\x6E\x65\x79\x20\x42\x61\x63\x6B\x20\x47\x75\x61\x72\x61\x6E\x74\x65\x65", "\x36\x30\x20\x44\x61\x79\x73\x20\x4D\x6F\x6E\x65\x79\x20\x42\x61\x63\x6B\x20\x47\x75\x61\x72\x61\x6E\x74\x65\x65", "\x39\x30\x20\x44\x61\x79\x73\x20\x4D\x6F\x6E\x65\x79\x20\x42\x61\x63\x6B\x20\x47\x75\x61\x72\x61\x6E\x74\x65\x65", "\x49\x6E\x76\x61\x6C\x69\x64\x20\x62\x69\x6C\x6C\x69\x6E\x67\x20\x63\x79\x63\x6C\x65\x20\x73\x65\x6C\x65\x63\x74\x65\x64\x3A", "\x2E\x70\x72\x69\x63\x69\x6E\x67\x2D\x74\x61\x62\x6C\x65\x20\x2E\x62\x69\x6C\x6C\x69\x6E\x67\x2D\x64\x65\x74\x61\x69\x6C\x73", "\x42\x69\x6C\x6C\x69\x6E\x67\x20\x64\x65\x74\x61\x69\x6C\x73\x20\x65\x6C\x65\x6D\x65\x6E\x74\x20\x6E\x6F\x74\x20\x66\x6F\x75\x6E\x64", "\x2E\x69\x6D\x70\x73\x64\x69\x70\x65\x73\x68", "\x64\x69\x73\x70\x6C\x61\x79", "\x73\x74\x79\x6C\x65", "\x6E\x6F\x6E\x65", "\x69\x6E\x6C\x69\x6E\x65\x2D\x62\x6C\x6F\x63\x6B", "\x73\x6C\x69\x64\x65\x2D\x69\x6E", "\x6C\x65\x6E\x67\x74\x68", "\x2E\x64\x6F\x6D\x61\x69\x6E\x2D\x6C\x69\x73\x74", "\x73\x70\x6C\x69\x74", "\x73\x68\x69\x66\x74", "\x3B", "\x70\x6F\x70", "\x64\x61\x74\x61\x2D\x65\x6E", "\x73\x65\x6C\x65\x63\x74\x65\x64\x49\x6E\x64\x65\x78", "\x6F\x70\x74\x69\x6F\x6E\x73", "\x64\x61\x74\x61\x2D\x63\x6F\x6E\x66\x69\x67", "\x76\x61\x6C\x75\x65", "\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x22\x63\x6F\x6E\x66\x69\x67\x6F\x70\x74\x69\x6F\x6E\x5B\x34\x31\x5D\x22\x5D", "\x61\x6E\x6E\x75\x61\x6C\x6C\x79", "\x2E\x73\x65\x72\x76\x65\x72\x5F\x6C\x6F\x63\x61\x74\x69\x6F\x6E", "\x3F\x63\x75\x72\x72\x65\x6E\x63\x79\x3D\x32", "\x26\x62\x69\x6C\x6C\x69\x6E\x67\x63\x79\x63\x6C\x65\x3D", "\x68\x72\x65\x66", "\x6C\x6F\x63\x61\x74\x69\x6F\x6E", "\x73\x65\x6C\x65\x63\x74\x2E\x73\x65\x72\x76\x65\x72\x5F\x6C\x6F\x63\x61\x74\x69\x6F\x6E", "\x63\x68\x61\x6E\x67\x65", "\x73\x70\x61\x72\x6B\x73\x68\x69\x66\x74\x2E\x68\x6F\x73\x74", "\x73\x70\x61\x72\x6B\x73\x68\x69\x66\x74\x2E\x75\x6B", "\x73\x70\x61\x72\x6B\x73\x68\x69\x66\x74", "\x68\x6F\x73\x74\x6E\x61\x6D\x65", "\x73\x6F\x6D\x65", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x73\x70\x61\x72\x6B\x73\x68\x69\x66\x74\x2E\x68\x6F\x73\x74"];
document[_$_ea80[48]](_$_ea80[0], function() {
    const currencyModal = new bootstrap[_$_ea80[3]](document[_$_ea80[2]](_$_ea80[1]), {
        backdrop: true,
        keyboard: true
    });

    function setCookie(name, value, days) {
        const expires = new Date(Date[_$_ea80[5]]() + days * 24 * 60 * 60 * 1000)[_$_ea80[4]]();
        document[_$_ea80[6]] = ("" + name + _$_ea80[7] + value + _$_ea80[8] + expires + _$_ea80[9])
    }

    function getCookie(name) {
        const matches = document[_$_ea80[6]][_$_ea80[14]](new RegExp(_$_ea80[10] + name[_$_ea80[12]](/([\.$?*|{}\(\)\[\]\\\/\+^])/g, _$_ea80[11]) + _$_ea80[13]));
        return matches ? decodeURIComponent(matches[1]) : undefined
    }
    async function getIPInfo() {
        try {
            const response = await fetch(_$_ea80[15]);
            if (!response[_$_ea80[16]]) {
                throw new Error(_$_ea80[17])
            };
            return await response[_$_ea80[18]]()
        } catch (error) {
            console[_$_ea80[20]](_$_ea80[19], error);
            return {}
        }
    }

    function setDefaultCurrencyByCode(currencyCode) {
        let defaultCurrency = _$_ea80[21];
        if (currencyCode === _$_ea80[22]) {
            defaultCurrency = _$_ea80[23]
        };
        setCookie(_$_ea80[24], defaultCurrency, 365);
        localStorage[_$_ea80[26]](_$_ea80[25], defaultCurrency);
        updateCurrencyButton();
        updatePrices(defaultCurrency)
    }

    function handleCurrencyChange(event) {
        event[_$_ea80[27]]();
        const selectedCurrency = this[_$_ea80[29]](_$_ea80[28]);
        setCookie(_$_ea80[24], selectedCurrency, 365);
        localStorage[_$_ea80[26]](_$_ea80[25], selectedCurrency);
        updatePrices(selectedCurrency);
        updateCurrencyButton();
        currencyModal[_$_ea80[30]]()
    }

    function updateCurrencyButton() {
        const currentCurrencyValue = getCookie(_$_ea80[24]) || localStorage[_$_ea80[31]](_$_ea80[25]) || _$_ea80[21];
        const currencyButton = document[_$_ea80[33]](_$_ea80[32]);
        let currencySymbol = _$_ea80[34];
        if (currentCurrencyValue === _$_ea80[23]) {
            currencySymbol = _$_ea80[35]
        };
        if (currencyButton) {
            currencyButton[_$_ea80[36]] = currencySymbol
        }
    }

    function updatePrices(currency) {
        document[_$_ea80[43]](_$_ea80[42])[_$_ea80[41]]((table) => {
            let price = _$_ea80[37];
            if (currency === _$_ea80[23]) {
                price = table[_$_ea80[29]](_$_ea80[38])
            } else {
                if (currency === _$_ea80[21]) {
                    price = table[_$_ea80[29]](_$_ea80[39])
                }
            };
            if (price !== _$_ea80[37]) {
                table[_$_ea80[33]](_$_ea80[40])[_$_ea80[36]] = price
            }
        })
    }(async function initializeCurrency() {
        let currentCurrencyValue = getCookie(_$_ea80[24]) || localStorage[_$_ea80[31]](_$_ea80[25]);
        if (!currentCurrencyValue) {
            const ipInfo = await getIPInfo();
            const currencyCode = ipInfo[_$_ea80[44]] || _$_ea80[45];
            setDefaultCurrencyByCode(currencyCode)
        } else {
            updateCurrencyButton();
            updatePrices(currentCurrencyValue)
        }
    })();
    const currencyItems = document[_$_ea80[43]](_$_ea80[46]);
    currencyItems[_$_ea80[41]]((item) => {
        item[_$_ea80[48]](_$_ea80[47], handleCurrencyChange)
    })
});
document[_$_ea80[48]](_$_ea80[0], function() {
    function updatePrices2() {
        const currency = getCookie(_$_ea80[24]) || localStorage[_$_ea80[31]](_$_ea80[25]) || _$_ea80[23];
        const billingCycle = document[_$_ea80[33]](_$_ea80[51])[_$_ea80[29]](_$_ea80[50])[_$_ea80[49]]();
        const currencySymbol = currency === _$_ea80[23] ? _$_ea80[52] : _$_ea80[53];
        const validCycles = [_$_ea80[54], _$_ea80[55], _$_ea80[56], _$_ea80[57]];
        if (!validCycles[_$_ea80[58]](billingCycle)) {
            return
        };
        document[_$_ea80[43]](_$_ea80[66])[_$_ea80[41]]((table) => {
            let price = _$_ea80[37];
            switch (currency) {
                case _$_ea80[23]:
                    price = table[_$_ea80[29]](("\x64\x61\x74\x61\x2D" + billingCycle + _$_ea80[59]));
                    break;
                case _$_ea80[21]:
                    price = table[_$_ea80[29]](("\x64\x61\x74\x61\x2D" + billingCycle + _$_ea80[60]));
                    break
            };
            const priceElement = table[_$_ea80[33]](_$_ea80[61]);
            if (priceElement) {
                if (price) {
                    priceElement[_$_ea80[62]] = ("" + currencySymbol + _$_ea80[37] + price + _$_ea80[63] + capitalizeFirstLetter(billingCycle) + _$_ea80[64])
                } else {
                    priceElement[_$_ea80[62]] = ("" + currencySymbol + _$_ea80[65])
                }
            }
        })
    }

    function capitalizeFirstLetter(string) {
        return string[_$_ea80[68]](0)[_$_ea80[67]]() + string[_$_ea80[69]](1)
    }

    function getCookie(name) {
        const matches = document[_$_ea80[6]][_$_ea80[14]](new RegExp(_$_ea80[10] + name[_$_ea80[12]](/([\.$?*|{}\(\)\[\]\\\/\+^])/g, _$_ea80[11]) + _$_ea80[13]));
        return matches ? decodeURIComponent(matches[1]) : undefined
    }
    const buttons = document[_$_ea80[43]](_$_ea80[70]);
    buttons[_$_ea80[41]]((button) => {
        button[_$_ea80[48]](_$_ea80[47], function(event) {
            event[_$_ea80[27]]();
            buttons[_$_ea80[41]]((btn) => {
                return btn[_$_ea80[73]][_$_ea80[72]](_$_ea80[71])
            });
            this[_$_ea80[73]][_$_ea80[74]](_$_ea80[71]);
            updatePrices2()
        })
    });

    function monitorCurrencyChanges() {
        let previousCurrency = getCookie(_$_ea80[24]) || localStorage[_$_ea80[31]](_$_ea80[25]) || _$_ea80[23];
        setInterval(() => {
            const currentCurrency = getCookie(_$_ea80[24]) || localStorage[_$_ea80[31]](_$_ea80[25]) || _$_ea80[23];
            if (currentCurrency !== previousCurrency) {
                previousCurrency = currentCurrency;
                updatePrices2()
            }
        }, 1000)
    }
    updatePrices2();
    monitorCurrencyChanges()
});
document[_$_ea80[48]](_$_ea80[0], function() {
    const billingDetails = {
        Monthly: _$_ea80[75],
        Yearly: _$_ea80[76],
        Biennially: _$_ea80[77],
        Triennially: _$_ea80[78]
    };

    function updateBillingDetails() {
        const selectedCycle = document[_$_ea80[33]](_$_ea80[51])[_$_ea80[29]](_$_ea80[50]);
        if (!billingDetails[selectedCycle]) {
            console[_$_ea80[20]](_$_ea80[79], selectedCycle);
            return
        };
        const billingDetailsElements = document[_$_ea80[43]](_$_ea80[80]);
        billingDetailsElements[_$_ea80[41]]((element) => {
            if (element) {
                element[_$_ea80[62]] = billingDetails[selectedCycle]
            } else {
                console[_$_ea80[20]](_$_ea80[81])
            }
        })
    }
    const buttons = document[_$_ea80[43]](_$_ea80[70]);
    buttons[_$_ea80[41]]((button) => {
        button[_$_ea80[48]](_$_ea80[47], function(event) {
            event[_$_ea80[27]]();
            buttons[_$_ea80[41]]((btn) => {
                return btn[_$_ea80[73]][_$_ea80[72]](_$_ea80[71])
            });
            this[_$_ea80[73]][_$_ea80[74]](_$_ea80[71]);
            updateBillingDetails()
        })
    });
    updateBillingDetails();

    function animateImageSlider(selector) {
        const sections = document[_$_ea80[43]](selector);
        sections[_$_ea80[41]]((section) => {
            const images = section[_$_ea80[43]](_$_ea80[82]);
            let currentIndex = 0;

            function showNextImage() {
                images[_$_ea80[41]]((img) => {
                    return img[_$_ea80[84]][_$_ea80[83]] = _$_ea80[85]
                });
                images[currentIndex][_$_ea80[84]][_$_ea80[83]] = _$_ea80[86];
                images[currentIndex][_$_ea80[73]][_$_ea80[74]](_$_ea80[87]);
                currentIndex = (currentIndex + 1) % images[_$_ea80[88]]
            }

            function animateImages() {
                setInterval(() => {
                    showNextImage()
                }, 3000)
            }
            images[_$_ea80[41]]((img, index) => {
                img[_$_ea80[84]][_$_ea80[83]] = index === 0 ? _$_ea80[86] : _$_ea80[85]
            });
            animateImages()
        })
    }
    animateImageSlider(_$_ea80[89])
});

function getCookie(name) {
    const value = ("\x3B\x20" + document[_$_ea80[6]] + _$_ea80[37]);
    const parts = value[_$_ea80[90]](("\x3B\x20" + name + _$_ea80[7]));
    if (parts[_$_ea80[88]] === 2) {
        return parts[_$_ea80[93]]()[_$_ea80[90]](_$_ea80[92])[_$_ea80[91]]()
    };
    return null
}

function updateConfigOption(selectElement) {
    if (selectElement[_$_ea80[29]](_$_ea80[94]) === _$_ea80[23]) {
        const selectedOption = selectElement[_$_ea80[96]][selectElement[_$_ea80[95]]];
        const configValue = selectedOption[_$_ea80[29]](_$_ea80[97]);
        document[_$_ea80[33]](_$_ea80[99])[_$_ea80[98]] = configValue
    }
}

function orderNow(orderPath) {
    const baseOrderUrl = ("\x68\x74\x74\x70\x73\x3A\x2F\x2F\x53\x70\x61\x72\x6B\x53\x68\x69\x66\x74\x2E\x48\x6F\x73\x74\x2F\x64\x61\x73\x68\x2F\x73\x74\x6F\x72\x65\x2F" + orderPath + _$_ea80[37]);
    const sparkCur = getCookie(_$_ea80[24]);
    const selectedCycle = document[_$_ea80[33]](_$_ea80[51])[_$_ea80[29]](_$_ea80[50]);
    const billingCycleMap = {
        Monthly: _$_ea80[54],
        Yearly: _$_ea80[100],
        Biennially: _$_ea80[56],
        Triennially: _$_ea80[57]
    };
    const billingCycleParam = billingCycleMap[selectedCycle] || _$_ea80[54];
    const selectedServerLocation = document[_$_ea80[33]](_$_ea80[101]);
    let serverConfigOption = _$_ea80[37];
    if (selectedServerLocation[_$_ea80[29]](_$_ea80[94]) === _$_ea80[23]) {
        serverConfigOption = selectedServerLocation[_$_ea80[96]][selectedServerLocation[_$_ea80[95]]][_$_ea80[29]](_$_ea80[97])
    };
    const currencyParam = (sparkCur === _$_ea80[21]) ? _$_ea80[102] : _$_ea80[37];
    let finalUrl = baseOrderUrl + (currencyParam ? ("" + currencyParam + _$_ea80[103] + billingCycleParam + _$_ea80[37]) : ("\x3F\x62\x69\x6C\x6C\x69\x6E\x67\x63\x79\x63\x6C\x65\x3D" + billingCycleParam + _$_ea80[37]));
    if (serverConfigOption) {
        finalUrl += ("\x26\x63\x6F\x6E\x66\x69\x67\x6F\x70\x74\x69\x6F\x6E\x5B\x34\x31\x5D\x3D" + serverConfigOption + _$_ea80[37])
    };
    window[_$_ea80[105]][_$_ea80[104]] = finalUrl
}
document[_$_ea80[43]](_$_ea80[106])[_$_ea80[41]](function(selectElement) {
    updateConfigOption(selectElement)
});
document[_$_ea80[43]](_$_ea80[106])[_$_ea80[41]](function(selectElement) {
    selectElement[_$_ea80[48]](_$_ea80[107], function() {
        updateConfigOption(selectElement)
    })
});
document[_$_ea80[43]](_$_ea80[70])[_$_ea80[41]]((button) => {
    button[_$_ea80[48]](_$_ea80[47], function(event) {
        event[_$_ea80[27]]();
        document[_$_ea80[43]](_$_ea80[70])[_$_ea80[41]]((btn) => {
            return btn[_$_ea80[73]][_$_ea80[72]](_$_ea80[71])
        });
        this[_$_ea80[73]][_$_ea80[74]](_$_ea80[71])
    })
});
const allowedDomains = [_$_ea80[108], _$_ea80[109], _$_ea80[110]];
const currentDomain = window[_$_ea80[105]][_$_ea80[111]];
const isAllowed = allowedDomains[_$_ea80[112]]((domain) => {
    return currentDomain[_$_ea80[58]](domain)
});
if (!isAllowed) {
    window[_$_ea80[105]][_$_ea80[104]] = _$_ea80[113]
}